class increment
{
public static void main(String []aa)
{
int a=5;
System.out.println("Initial number is 5");
a++;
System.out.println("Postfix value =" +a);
++a;
System.out.println("Prefix value =" +a);
}
}