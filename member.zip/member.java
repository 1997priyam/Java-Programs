class member
{
int a=10;
void display()
{
System.out.println("Value of the variable is "+a);
}
public static void main(String []aa)
{
member obj = new member();
obj.display();
}

}